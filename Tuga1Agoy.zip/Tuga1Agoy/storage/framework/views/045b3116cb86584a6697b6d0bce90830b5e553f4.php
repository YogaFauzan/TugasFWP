<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Biodata - <?php echo $__env->yieldContent('nama_title'); ?></title>
</head>
<body>
    <h1>BIODATA
        <h2><?php echo $__env->yieldContent('nama_heading'); ?></h2>
</div>
<div id="bio">
    <p><?php echo $__env->yieldContent('bio'); ?></p>
</div>
<div id="TTL">

    <p><?php echo $__env->yieldContent('TTL'); ?></p>
</div>
<div id="bio">
    <div>
        Makanan Favorit:
    </div>
    <div>
        <?php echo $__env->yieldContent('makananfavorit'); ?>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\laragon\www\Tuga1Agoy\resources\views/utama.blade.php ENDPATH**/ ?>