<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class yoga extends Controller
{
    public function index(){

        $nama = "MUHAMAD YOGA FAUZAN";
        $bio = "Saya merupakan anak ke-2 dari 3 bersaudara";
        $makananfavorit = ["Nasi Goreng","Bakso","Siomay"];
        $TTL = " TTL : Sumedang, 11 Juli 2022";
        return view('kedua',['nama'=>$nama, 'bio'=>$bio, 'makananfavorit'=>$makananfavorit, 'TTL'=>$TTL]);
    }
}
