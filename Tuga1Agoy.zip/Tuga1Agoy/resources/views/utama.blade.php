<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Biodata - @yield('nama_title')</title>
</head>
<body>
    <h1>BIODATA
        <h2>@yield('nama_heading')</h2>
</div>
<div id="bio">
    <p>@yield('bio')</p>
</div>
<div id="TTL">

    <p>@yield('TTL')</p>
</div>
<div id="bio">
    <div>
        Makanan Favorit:
    </div>
    <div>
        @yield('makananfavorit')
    </div>
</div>

</body>
</html>
