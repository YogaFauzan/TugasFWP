@extends('utama')

@section('nama_title',$nama)

@section('nama_heading',$nama)

@section('bio',$bio)

@section('TTL',$TTL)

@section('makananfavorit')
@forelse ($makananfavorit as $item)
    <li>{{$item}}</li>
@empty

@endforelse
@endsection
